
import React, { useState, useEffect } from 'react';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import { User, AuthMap, Lead } from './types';
import { BASE_USERS, LOCAL_STORAGE_KEYS } from './constants';

const App: React.FC = () => {
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [authMap, setAuthMap] = useState<AuthMap>({});
    const [leads, setLeads] = useState<Lead[]>([]);

    useEffect(() => {
        // Load or initialize Auth
        const storedAuth = localStorage.getItem(LOCAL_STORAGE_KEYS.AUTH);
        let currentAuth: AuthMap = {};
        if (storedAuth) {
            currentAuth = JSON.parse(storedAuth);
        } else {
            // Initialize with default password '123'
            Object.keys(BASE_USERS).forEach(userId => {
                currentAuth[userId] = "123";
            });
            localStorage.setItem(LOCAL_STORAGE_KEYS.AUTH, JSON.stringify(currentAuth));
        }
        setAuthMap(currentAuth);

        // Load Leads
        const storedLeads = localStorage.getItem(LOCAL_STORAGE_KEYS.LEADS);
        if (storedLeads) {
            setLeads(JSON.parse(storedLeads));
        }
    }, []);

    const handleLogin = (user: User) => {
        setCurrentUser(user);
    };

    const handleLogout = () => {
        setCurrentUser(null);
    };

    const updateLeads = (newLeads: Lead[]) => {
        setLeads(newLeads);
        localStorage.setItem(LOCAL_STORAGE_KEYS.LEADS, JSON.stringify(newLeads));
    };

    const updateAuth = (newAuth: AuthMap) => {
        setAuthMap(newAuth);
        localStorage.setItem(LOCAL_STORAGE_KEYS.AUTH, JSON.stringify(newAuth));
    };

    return (
        <div className="min-h-screen bg-slate-50">
            {!currentUser ? (
                <Login authMap={authMap} onLogin={handleLogin} />
            ) : (
                <Dashboard 
                    currentUser={currentUser} 
                    leads={leads} 
                    onUpdateLeads={updateLeads} 
                    onLogout={handleLogout}
                    authMap={authMap}
                    onUpdateAuth={updateAuth}
                />
            )}
        </div>
    );
};

export default App;
