
import React from 'react';
import { AuthMap } from '../types';
import { BASE_USERS } from '../constants';

interface AdminPanelProps {
    authMap: AuthMap;
    onUpdateAuth: (auth: AuthMap) => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ authMap, onUpdateAuth }) => {
    const handleReset = (userId: string) => {
        if (confirm(`Deseja realmente resetar a senha de ${BASE_USERS[userId].name} para "123"?`)) {
            onUpdateAuth({ ...authMap, [userId]: "123" });
            alert("Senha resetada com sucesso!");
        }
    };

    return (
        <div className="bg-amber-50 border border-amber-100 rounded-2xl p-6 mb-8 animate-in slide-in-from-top-4 duration-300">
            <h2 className="text-amber-800 font-extrabold text-sm uppercase tracking-widest mb-4 flex items-center gap-2">
                <i className="fa-solid fa-shield-halved"></i> Painel de Administração - Senhas
            </h2>
            <p className="text-xs text-amber-600 mb-6">Resetar senhas de corretores para o padrão "123":</p>
            <div className="flex flex-wrap gap-3">
                {Object.entries(BASE_USERS).filter(([id]) => id !== 'admin').map(([id, u]) => (
                    <button 
                        key={id}
                        onClick={() => handleReset(id)}
                        className="bg-white border border-amber-200 text-amber-800 px-4 py-2 rounded-lg text-[11px] font-bold hover:bg-amber-100 transition-colors flex items-center gap-2 shadow-sm"
                    >
                        <i className="fa-solid fa-rotate-left"></i> Resetar {u.name}
                    </button>
                ))}
            </div>
        </div>
    );
};

export default AdminPanel;
