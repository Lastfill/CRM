
import React, { useState, useMemo } from 'react';
import { User, Lead, LeadStatus, UserRole, AuthMap } from '../types';
import { BASE_USERS } from '../constants';
import LeadTable from './LeadTable';
import LeadForm from './LeadForm';
import LeadModal from './LeadModal';
import AdminPanel from './AdminPanel';

interface DashboardProps {
    currentUser: User;
    leads: Lead[];
    onUpdateLeads: (leads: Lead[]) => void;
    onLogout: () => void;
    authMap: AuthMap;
    onUpdateAuth: (auth: AuthMap) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ 
    currentUser, leads, onUpdateLeads, onLogout, authMap, onUpdateAuth 
}) => {
    const [showForm, setShowForm] = useState(false);
    const [showAdmin, setShowAdmin] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [filterCorretor, setFilterCorretor] = useState('todos');
    const [activeLead, setActiveLead] = useState<Lead | null>(null);

    const filteredLeads = useMemo(() => {
        let items = leads;
        if (currentUser.role !== UserRole.ADMIN) {
            items = items.filter(l => l.corretor === currentUser.id);
        } else if (filterCorretor !== 'todos') {
            items = items.filter(l => l.corretor === filterCorretor);
        }

        if (searchTerm) {
            items = items.filter(l => 
                l.nome.toLowerCase().includes(searchTerm.toLowerCase()) || 
                l.email.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }
        return items.sort((a, b) => new Date(b.dataAtt).getTime() - new Date(a.dataAtt).getTime());
    }, [leads, currentUser, filterCorretor, searchTerm]);

    const handleAddLead = (newLead: Lead) => {
        onUpdateLeads([newLead, ...leads]);
        setShowForm(false);
    };

    const handleUpdateLead = (updatedLead: Lead) => {
        const newLeads = leads.map(l => l.id === updatedLead.id ? updatedLead : l);
        onUpdateLeads(newLeads);
        setActiveLead(null);
    };

    const handleChangePassword = () => {
        const newPass = prompt("Digite sua nova senha (mínimo 3 caracteres):");
        if (newPass && newPass.length >= 3) {
            onUpdateAuth({ ...authMap, [currentUser.id]: newPass });
            alert("Senha alterada com sucesso!");
        }
    };

    const exportToExcel = () => {
        if (currentUser.role !== UserRole.ADMIN) return;
        const csvRows = [
            "\uFEFFNome;Email;Telefone;Imovel;Link Imovel;Status;Corretor;Data Cadastro;Data Atualizacao"
        ];
        leads.forEach(l => {
            csvRows.push(`${l.nome};${l.email};${l.tel};${l.imovel};${l.imovelLink || ""};${l.status};${BASE_USERS[l.corretor]?.name || l.corretor};${l.dataCad};${l.dataAtt}`);
        });
        const blob = new Blob([csvRows.join("\n")], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = "Relatorio_Leads_Vinutto.csv";
        link.click();
    };

    return (
        <div className="flex flex-col h-screen">
            <header className="bg-[#0f172a] text-white px-6 py-4 flex flex-col md:flex-row justify-between items-center sticky top-0 z-50 shadow-lg">
                <div className="text-xl font-extrabold tracking-tighter mb-4 md:mb-0">VINUTTO CRM</div>
                
                <div className="mb-4 md:mb-0">
                    <a href="https://robsonvinuto.com.br/lancamento/lancamento.html" 
                       target="_blank" 
                       rel="noopener noreferrer" 
                       className="bg-[#ca8a04] hover:bg-yellow-700 text-white py-2 px-5 rounded-lg font-bold text-xs uppercase flex items-center gap-2 shadow-xl transition-all">
                        <i className="fa-solid fa-book"></i> BOOKS / TABELAS
                    </a>
                </div>

                <div className="flex items-center gap-4 text-xs font-semibold">
                    <span className="hidden sm:inline">Bem-vindo, {currentUser.name}</span>
                    <button onClick={handleChangePassword} className="bg-slate-700 hover:bg-slate-600 px-3 py-1.5 rounded transition-colors">
                        <i className="fa-solid fa-key mr-1"></i> Senha
                    </button>
                    {currentUser.role === UserRole.ADMIN && (
                        <button onClick={() => setShowAdmin(!showAdmin)} className="bg-amber-800 hover:bg-amber-700 px-3 py-1.5 rounded transition-colors">
                            <i className="fa-solid fa-gear mr-1"></i> Admin
                        </button>
                    )}
                    <button onClick={onLogout} className="bg-red-600 hover:bg-red-500 px-3 py-1.5 rounded transition-colors">
                        Sair
                    </button>
                </div>
            </header>

            <main className="flex-1 overflow-auto p-4 md:p-8 max-w-7xl mx-auto w-full">
                {showAdmin && (
                    <AdminPanel 
                        authMap={authMap} 
                        onUpdateAuth={onUpdateAuth} 
                    />
                )}

                <div className="flex flex-wrap gap-4 mb-6">
                    <button 
                        onClick={() => setShowForm(!showForm)} 
                        className="bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 shadow-md"
                    >
                        <i className="fa-solid fa-plus"></i> NOVO LEAD
                    </button>
                    {currentUser.role === UserRole.ADMIN && (
                        <button 
                            onClick={exportToExcel}
                            className="bg-teal-600 hover:bg-teal-700 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 shadow-md"
                        >
                            <i className="fa-solid fa-file-excel"></i> EXPORTAR CSV
                        </button>
                    )}
                </div>

                {showForm && (
                    <LeadForm onAddLead={handleAddLead} currentUser={currentUser} />
                )}

                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 mb-6 flex flex-col md:flex-row gap-6 items-end">
                    <div className="flex-1 w-full">
                        <label className="block text-[10px] font-extrabold text-slate-500 uppercase mb-2">Buscar Cliente</label>
                        <div className="relative">
                            <i className="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
                            <input 
                                type="text" 
                                placeholder="Nome ou email..." 
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                            />
                        </div>
                    </div>
                    {currentUser.role === UserRole.ADMIN && (
                        <div className="flex-1 w-full">
                            <label className="block text-[10px] font-extrabold text-slate-500 uppercase mb-2">Filtrar por Corretor</label>
                            <select 
                                value={filterCorretor}
                                onChange={(e) => setFilterCorretor(e.target.value)}
                                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                                <option value="todos">Todos os Corretores</option>
                                {Object.entries(BASE_USERS).filter(([id]) => id !== 'admin').map(([id, u]) => (
                                    <option key={id} value={id}>{u.name}</option>
                                ))}
                            </select>
                        </div>
                    )}
                </div>

                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                    <LeadTable 
                        leads={filteredLeads} 
                        onOpenLead={setActiveLead} 
                        users={BASE_USERS}
                    />
                </div>
            </main>

            {activeLead && (
                <LeadModal 
                    lead={activeLead} 
                    onClose={() => setActiveLead(null)} 
                    onSave={handleUpdateLead}
                />
            )}
        </div>
    );
};

export default Dashboard;
