
import React, { useState, useEffect, useRef } from 'react';
import { Lead, LeadStatus, User, UserRole } from '../types';
import { BASE_USERS } from '../constants';

interface LeadFormProps {
    onAddLead: (lead: Lead) => void;
    currentUser: User;
}

const LeadForm: React.FC<LeadFormProps> = ({ onAddLead, currentUser }) => {
    const [nome, setNome] = useState('');
    const [email, setEmail] = useState('');
    const [tel, setTel] = useState('');
    const [imovel, setImovel] = useState('');
    const [imovelLink, setImovelLink] = useState('');
    const [corretor, setCorretor] = useState(currentUser.role === UserRole.ADMIN ? 'marcus.barbosa' : currentUser.id);
    
    const phoneInputRef = useRef<HTMLInputElement>(null);
    const itiRef = useRef<any>(null);

    useEffect(() => {
        if (phoneInputRef.current) {
            itiRef.current = (window as any).intlTelInput(phoneInputRef.current, {
                initialCountry: "br",
                separateDialCode: true,
                utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js"
            });
        }
    }, []);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!nome) {
            alert("Nome é obrigatório!");
            return;
        }

        const formattedTel = itiRef.current?.getNumber() || tel;
        const now = new Date().toLocaleString('pt-BR');
        
        const newLead: Lead = {
            id: Date.now(),
            nome,
            email,
            tel: formattedTel,
            imovel: imovel || 'N/A',
            imovelLink,
            dataCad: now,
            dataAtt: now,
            corretor,
            status: LeadStatus.ATENDIMENTO,
            hist: [{ data: now, note: "Cadastrado no CRM", status: LeadStatus.ATENDIMENTO }]
        };

        onAddLead(newLead);
        setNome('');
        setEmail('');
        setTel('');
        setImovel('');
        setImovelLink('');
    };

    return (
        <form onSubmit={handleSubmit} className="bg-white p-6 rounded-2xl shadow-sm border border-emerald-100 mb-6 grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4 items-end">
            <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase">Nome do Cliente</label>
                <input required type="text" value={nome} onChange={e => setNome(e.target.value)} className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm" />
            </div>
            <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase">WhatsApp</label>
                <input ref={phoneInputRef} type="tel" value={tel} onChange={e => setTel(e.target.value)} className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm" />
            </div>
            <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase">E-mail</label>
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm" />
            </div>
            <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase">Cód. Imóvel</label>
                <input type="text" value={imovel} onChange={e => setImovel(e.target.value)} className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm" />
            </div>
            <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase">Link do Imóvel</label>
                <input type="url" placeholder="https://..." value={imovelLink} onChange={e => setImovelLink(e.target.value)} className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm" />
            </div>
            {currentUser.role === UserRole.ADMIN && (
                <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Corretor Responsável</label>
                    <select value={corretor} onChange={e => setCorretor(e.target.value)} className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm h-[38px]">
                        {Object.entries(BASE_USERS).filter(([id]) => id !== 'admin').map(([id, u]) => (
                            <option key={id} value={id}>{u.name}</option>
                        ))}
                    </select>
                </div>
            )}
            <div className="md:col-span-1 lg:col-span-1">
                <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg shadow-md transition-colors h-[38px]">
                    CADASTRAR
                </button>
            </div>
        </form>
    );
};

export default LeadForm;
