
import React, { useState, useEffect, useRef } from 'react';
import { Lead, LeadStatus } from '../types';

interface LeadModalProps {
    lead: Lead;
    onClose: () => void;
    onSave: (lead: Lead) => void;
}

const LeadModal: React.FC<LeadModalProps> = ({ lead, onClose, onSave }) => {
    const [tel, setTel] = useState(lead.tel);
    const [email, setEmail] = useState(lead.email);
    const [imovel, setImovel] = useState(lead.imovel);
    const [imovelLink, setImovelLink] = useState(lead.imovelLink || '');
    const [status, setStatus] = useState<LeadStatus>(lead.status);
    const [note, setNote] = useState('');

    const phoneInputRef = useRef<HTMLInputElement>(null);
    const itiRef = useRef<any>(null);

    useEffect(() => {
        if (phoneInputRef.current) {
            itiRef.current = (window as any).intlTelInput(phoneInputRef.current, {
                initialCountry: "br",
                separateDialCode: true,
                utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js"
            });
            itiRef.current.setNumber(lead.tel);
        }
    }, [lead]);

    const handleSave = () => {
        if (!note) {
            alert("Favor descrever o feedback da atualização.");
            return;
        }

        const now = new Date().toLocaleString('pt-BR');
        const formattedTel = itiRef.current?.getNumber() || tel;

        const updatedLead: Lead = {
            ...lead,
            tel: formattedTel,
            email,
            imovel,
            imovelLink,
            status,
            dataAtt: now,
            hist: [
                ...lead.hist,
                { data: now, note, status }
            ]
        };

        onSave(updatedLead);
    };

    return (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-[100] p-4">
            <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col animate-in fade-in zoom-in duration-200">
                <div className="px-8 py-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                    <div>
                        <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">{lead.nome}</h2>
                        <p className="text-[10px] uppercase font-bold text-slate-400 mt-1">Lead ID: {lead.id}</p>
                    </div>
                    <button onClick={onClose} className="text-slate-400 hover:text-slate-600 p-2 rounded-full hover:bg-slate-200 transition-colors">
                        <i className="fa-solid fa-xmark text-xl"></i>
                    </button>
                </div>

                <div className="flex-1 overflow-y-auto p-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <label className="text-[10px] font-bold text-slate-500 uppercase">WhatsApp</label>
                            <input ref={phoneInputRef} type="tel" className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none" />
                        </div>
                        <div className="space-y-2">
                            <label className="text-[10px] font-bold text-slate-500 uppercase">E-mail</label>
                            <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none" />
                        </div>
                        <div className="space-y-2">
                            <label className="text-[10px] font-bold text-slate-500 uppercase">Cód. Imóvel</label>
                            <input type="text" value={imovel} onChange={e => setImovel(e.target.value)} className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none" />
                        </div>
                        <div className="space-y-2">
                            <label className="text-[10px] font-bold text-slate-500 uppercase">Link do Imóvel</label>
                            <input type="url" value={imovelLink} onChange={e => setImovelLink(e.target.value)} className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none" />
                        </div>
                        <div className="md:col-span-2 space-y-2">
                            <label className="text-[10px] font-bold text-slate-500 uppercase">Status do Lead</label>
                            <div className="flex flex-wrap gap-2">
                                {Object.values(LeadStatus).map(s => (
                                    <button 
                                        key={s} 
                                        type="button"
                                        onClick={() => setStatus(s)}
                                        className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider border transition-all ${status === s ? 'bg-slate-900 border-slate-900 text-white' : 'bg-white border-slate-200 text-slate-400 hover:border-slate-300'}`}
                                    >
                                        {s}
                                    </button>
                                ))}
                            </div>
                        </div>
                        <div className="md:col-span-2 space-y-2">
                            <label className="text-[10px] font-bold text-slate-500 uppercase">Feedback / Observações</label>
                            <textarea 
                                value={note} 
                                onChange={e => setNote(e.target.value)}
                                placeholder="Descreva o que foi conversado ou o motivo da mudança de status..."
                                className="w-full px-4 py-3 border border-slate-200 rounded-2xl h-24 resize-none outline-none focus:ring-2 focus:ring-blue-500"
                            ></textarea>
                        </div>
                    </div>

                    <div className="mt-10">
                        <h3 className="text-sm font-extrabold text-slate-900 border-b border-slate-100 pb-3 flex items-center gap-2">
                            <i className="fa-solid fa-clock-rotate-left text-slate-400"></i> HISTÓRICO DE ATIVIDADES
                        </h3>
                        <div className="mt-4 space-y-4">
                            {lead.hist.slice().reverse().map((h, i) => (
                                <div key={i} className="flex gap-4">
                                    <div className="flex flex-col items-center">
                                        <div className="w-2.5 h-2.5 rounded-full bg-blue-500 mt-1.5"></div>
                                        {i !== lead.hist.length - 1 && <div className="w-px flex-1 bg-slate-200 my-1"></div>}
                                    </div>
                                    <div className="flex-1 pb-4">
                                        <div className="flex justify-between items-start">
                                            <span className="text-[11px] font-bold text-slate-900">{h.data}</span>
                                            <span className={`status-badge status-${h.status}`}>{h.status}</span>
                                        </div>
                                        <p className="text-sm text-slate-600 mt-1 leading-relaxed">{h.note}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                <div className="px-8 py-6 bg-slate-50 border-t border-slate-100 flex gap-4">
                    <button onClick={onClose} className="flex-1 px-6 py-3 bg-white border border-slate-200 text-slate-600 font-bold rounded-xl hover:bg-slate-50 transition-colors">
                        CANCELAR
                    </button>
                    <button onClick={handleSave} className="flex-[2] px-6 py-3 bg-slate-900 text-white font-bold rounded-xl hover:bg-black transition-all shadow-lg">
                        SALVAR ATUALIZAÇÕES
                    </button>
                </div>
            </div>
        </div>
    );
};

export default LeadModal;
