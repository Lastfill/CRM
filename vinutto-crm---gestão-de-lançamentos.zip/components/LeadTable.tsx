
import React from 'react';
import { Lead, LeadStatus, UserRole } from '../types';

interface LeadTableProps {
    leads: Lead[];
    onOpenLead: (lead: Lead) => void;
    users: any;
}

const LeadTable: React.FC<LeadTableProps> = ({ leads, onOpenLead, users }) => {
    return (
        <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[1000px]">
                <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-[10px] font-extrabold text-slate-500 uppercase tracking-wider">
                        <th className="px-6 py-4">Cliente / E-mail</th>
                        <th className="px-6 py-4">Telefone</th>
                        <th className="px-6 py-4">Datas (Cad/Att)</th>
                        <th className="px-6 py-4">Imóvel</th>
                        <th className="px-6 py-4">Corretor</th>
                        <th className="px-6 py-4">Status</th>
                        <th className="px-6 py-4 text-center">Ações</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                    {leads.length === 0 ? (
                        <tr>
                            <td colSpan={7} className="px-6 py-12 text-center text-slate-400 italic font-medium">
                                Nenhum lead encontrado.
                            </td>
                        </tr>
                    ) : (
                        leads.map(lead => (
                            <tr key={lead.id} className="hover:bg-slate-50 transition-colors group">
                                <td className="px-6 py-4">
                                    <div className="font-bold text-slate-900 leading-tight">{lead.nome}</div>
                                    <div className="text-xs text-slate-400">{lead.email || 'Sem e-mail'}</div>
                                </td>
                                <td className="px-6 py-4 font-semibold text-slate-700">{lead.tel}</td>
                                <td className="px-6 py-4 text-[11px]">
                                    <div className="text-slate-400">Cad: {lead.dataCad}</div>
                                    <div className="text-blue-600 font-bold">Att: {lead.dataAtt}</div>
                                </td>
                                <td className="px-6 py-4">
                                    {lead.imovelLink ? (
                                        <a href={lead.imovelLink} target="_blank" className="text-blue-600 font-bold hover:underline">
                                            {lead.imovel} <i className="fa-solid fa-arrow-up-right-from-square text-[8px]"></i>
                                        </a>
                                    ) : (
                                        <span className="font-medium text-slate-600">{lead.imovel}</span>
                                    )}
                                </td>
                                <td className="px-6 py-4 text-xs font-medium text-slate-500 uppercase">
                                    {users[lead.corretor]?.name || lead.corretor}
                                </td>
                                <td className="px-6 py-4">
                                    <span className={`status-badge status-${lead.status}`}>
                                        {lead.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-center">
                                    <button 
                                        onClick={() => onOpenLead(lead)} 
                                        className="bg-slate-900 hover:bg-black text-white px-4 py-2 rounded-lg text-[11px] font-bold shadow-sm transition-all group-hover:scale-105"
                                    >
                                        DETALHES
                                    </button>
                                </td>
                            </tr>
                        ))
                    )}
                </tbody>
            </table>
        </div>
    );
};

export default LeadTable;
