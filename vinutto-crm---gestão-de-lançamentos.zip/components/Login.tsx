
import React, { useState } from 'react';
import { User, AuthMap } from '../types';
import { BASE_USERS } from '../constants';

interface LoginProps {
    authMap: AuthMap;
    onLogin: (user: User) => void;
}

const Login: React.FC<LoginProps> = ({ authMap, onLogin }) => {
    const [userId, setUserId] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const id = userId.toLowerCase().trim();
        
        if (BASE_USERS[id] && authMap[id] === password) {
            onLogin({ id, ...BASE_USERS[id] });
        } else {
            setError('Login ou senha inválidos.');
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center p-6 bg-[#0f172a] bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]">
            <div className="w-full max-w-sm bg-white rounded-[2rem] shadow-2xl p-10 transform transition-all hover:scale-[1.01]">
                <div className="flex flex-col items-center mb-10">
                    <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center text-white text-3xl mb-6 shadow-xl shadow-blue-500/30">
                        <i className="fa-solid fa-users-rectangle"></i>
                    </div>
                    <h1 className="text-3xl font-extrabold text-slate-900 tracking-tighter">VINUTTO CRM</h1>
                    <p className="text-slate-400 font-bold text-[10px] uppercase tracking-widest mt-2">Gestão de Lançamentos</p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="space-y-2">
                        <label className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider ml-1">Usuário</label>
                        <div className="relative">
                            <i className="fa-solid fa-user absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
                            <input 
                                type="text" 
                                required
                                value={userId}
                                onChange={e => setUserId(e.target.value)}
                                className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-sm font-medium"
                                placeholder="seu.login"
                            />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <label className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider ml-1">Senha</label>
                        <div className="relative">
                            <i className="fa-solid fa-lock absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
                            <input 
                                type="password" 
                                required
                                value={password}
                                onChange={e => setPassword(e.target.value)}
                                className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-sm font-medium"
                                placeholder="••••••••"
                            />
                        </div>
                    </div>

                    {error && (
                        <div className="bg-red-50 text-red-500 text-xs font-bold py-3 px-4 rounded-xl flex items-center gap-2 animate-bounce">
                            <i className="fa-solid fa-circle-exclamation"></i> {error}
                        </div>
                    )}

                    <button 
                        type="submit" 
                        className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white font-black rounded-2xl shadow-xl shadow-blue-600/20 transform transition-all active:scale-95 text-sm uppercase tracking-widest"
                    >
                        Acessar Painel
                    </button>
                </form>

                <div className="mt-8 pt-8 border-t border-slate-100 text-center">
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tight">
                        © 2025 VINUTTO IMÓVEIS
                    </p>
                </div>
            </div>
        </div>
    );
};

export default Login;
